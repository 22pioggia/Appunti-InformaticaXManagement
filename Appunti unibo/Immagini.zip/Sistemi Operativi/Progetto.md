### Gruppi

- i gruppi saranno composti da 3/4 persone - gruppi da 5 saranno più esigenti
- i gruppi vanno comunicati via mail entro il **31 maggio 2024**
#### Mail

Oggetto: [LABSO] FORMAZIONE GRUPPO
- Nome gruppo
- Per ogni componente: nome, cognome, numero di matricola
- Indirizzo mail referente
### Repository
il codice dovrà essere caricato su un repository GitHub
### Progetto
bisogna implementare un servizio publish/subscribe, dove multipli client possono "iscriversi" a determinati topic

### Linguaggio
bisogna usare Java, possibilmente le ultime versioni
# XX

il coglione continua a elencare cose senza dare il tempo di scrivere un cazzo quindi pace.