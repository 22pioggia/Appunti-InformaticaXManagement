public class Client {
    //troppo lungo, ha scritto per mezz'ora e io sono lento e assonnato.
}
